function z = convZp(x, y, p)
    z = mod(conv(x,y), p);
end

