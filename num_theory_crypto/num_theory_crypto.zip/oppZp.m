function z = oppZp(x, p)
    z = mod(-x, p);
end