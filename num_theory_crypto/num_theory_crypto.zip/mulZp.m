function z = mulZp(x, y, p)
    z = mod(x * y, p);
end

